var config = {
    closeTimer:'TIMER', // TIMER or NOTIMER
    sound:'unmuted'
}

